/*
 * Copyright (C) 2017, hapjs.org. All rights reserved.
 */
module.exports = require('./lib/loader')
