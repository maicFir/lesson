/*
 * Copyright (C) 2017, Xiaomi Inc. All rights reserved.
 */
// 启动
appImpl.init();
